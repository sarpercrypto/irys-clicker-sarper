let data = 0;
let nodes = 0;

const dataDisplay = document.getElementById("data");
const nodeDisplay = document.getElementById("nodes");
const clickButton = document.getElementById("clickButton");
const buyNodeButton = document.getElementById("buyNode");

// Tıklayınca veri arttır
clickButton.addEventListener("click", () => {
  data++;
  dataDisplay.textContent = data;
});

// Node satın alma
buyNodeButton.addEventListener("click", () => {
  if (data >= 10) {
    data -= 10;
    nodes++;
    dataDisplay.textContent = data;
    nodeDisplay.textContent = nodes;
  } else {
    alert("Yeterli verin yok!");
  }
});

// Otomatik veri kazancı (her saniye)
setInterval(() => {
  data += nodes;
  dataDisplay.textContent = data;
}, 1000);